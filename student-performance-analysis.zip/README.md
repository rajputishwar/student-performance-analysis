# Student Performance Analysis

This project predicts student performance using machine learning.

## Tech Stack
Python, Pandas, Scikit-learn, Matplotlib

## How to Run
pip install -r requirements.txt
python app.py
